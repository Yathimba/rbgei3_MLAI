############################ FINAL(2) ############################

#write the parser to disk

from pathlib import Path
import re
import pandas as pd

LETTER_MAP = {
    "a": "thickness_um_rb", "b": "Eg_eV_rb", "c": "chi_eV_rb", "d": "eps_r_rb",
    "e": "NA_cm3_rb", "f": "ND_cm3_rb", "g": "Nt_cm3_rb",
    "p": "Jsc_mAcm2", "q": "Voc_V", "r": "FF_pct", "s": "PCE_pct",
    "t": "Vmpp_V", "u": "Jmpp_mAcm2", "z": "Rs_ohmcm2",
}
_VALUE_RE = re.compile(r"^([a-z])value\s*$")


def parse_file(path):
    path = Path(path)
    raw = {}
    with path.open("r", errors="replace") as fh:
        for line in fh:
            if line.startswith("dimension"):
                break
            parts = line.rstrip("\n").split("\t")
            if len(parts) < 2:
                continue
            m = _VALUE_RE.match(parts[0])
            if not m:
                continue
            try:
                raw[m.group(1)] = float(parts[1].strip())
            except ValueError:
                continue
    if not raw:
        raise ValueError(f"{path.name}: no scalar values found")
    missing = set(LETTER_MAP) - set(raw)
    if missing:
        raise ValueError(f"{path.name}: missing letters {sorted(missing)}")
    row = {name: raw[l] for l, name in LETTER_MAP.items()}
    row["source_file"] = path.name
    return row


def parse_folder(folder, pattern="p*.txt", strict=True):
    folder = Path(folder)
    files = sorted(folder.glob(pattern))
    if not files:
        raise FileNotFoundError(f"no files matching {pattern!r} in {folder}")
    rows, failed = [], []
    for f in files:
        try:
            rows.append(parse_file(f))
        except ValueError as exc:
            if strict:
                raise
            failed.append((f.name, str(exc)))
    df = pd.DataFrame(rows)
    df["point_id"] = df["source_file"].str.extract(r"(\d+)", expand=False).astype(int)
    df = df.sort_values("point_id").reset_index(drop=True)
    df.attrs["failed"] = failed
    return df


def check_identities(df, tol=1e-3):
    df = df.copy()
    pce_a = df["Jsc_mAcm2"] * df["Voc_V"] * df["FF_pct"] / 100.0
    pce_b = df["Vmpp_V"] * df["Jmpp_mAcm2"]
    denom = df["PCE_pct"].abs().clip(lower=1e-12)
    df["ident_A_relerr"] = (pce_a - df["PCE_pct"]).abs() / denom
    df["ident_B_relerr"] = (pce_b - df["PCE_pct"]).abs() / denom
    df["flag_identity"] = (df["ident_A_relerr"] > tol) | (df["ident_B_relerr"] > tol)
    df["flag_voc_gt_eg"] = df["Voc_V"] > df["Eg_eV_rb"]
    df["flag_dead"] = df["Jsc_mAcm2"].abs() < 1e-3
    df["flag_zero_readback"] = df["Eg_eV_rb"] < 1e-9
    return df


def check_readbacks(df, design, rtol=1e-9):
    pairs = [("thickness_um_rb", "thickness_um"), ("Eg_eV_rb", "Eg_eV"),
             ("chi_eV_rb", "chi_eV"), ("eps_r_rb", "eps_r"),
             ("NA_cm3_rb", "NA_cm3"), ("ND_cm3_rb", "ND_cm3"),
             ("Nt_cm3_rb", "Nt_cm3")]
    merged = df.set_index("point_id").join(design, how="left", rsuffix="_design")
    bad = pd.Series(False, index=merged.index)
    for rb, want in pairs:
        rel = (merged[rb] - merged[want]).abs() / merged[want].abs().clip(lower=1e-30)
        bad |= rel > rtol
    return merged[bad]